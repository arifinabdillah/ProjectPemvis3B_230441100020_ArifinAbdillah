
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DIKNAS
 */
public class T_User {
    //Atribut URL, USER, dan PASS menyimpan detail koneksi ke database
    private final String URL = "jdbc:mysql://localhost:3306/db_edukasi";
    private final String USER = "root";
    private final String PASS = ""; //default string kosong
    
    //Metode ini mengembalikan objek Connection yang membuka koneksi ke database dengan menggunakan URL, USER, dan PASS
    Connection getConnection()  throws SQLException {
       return DriverManager.getConnection(URL, USER, PASS );            
    }
    //Metode ini digunakan untuk memverifikasi kredensial login pengguna dengan mencocokkan username dan password
    public User getUserLogin(User p_mrd) throws SQLException {
    //Sebuah variabel User diinisialisasi dengan null. Ini akan berisi data pengguna yang cocok dengan username dan password jika ditemukan dalam database.
        User user = null;
        
        // Query SQL untuk mengambil data pengguna dari tabel users dengan kondisi username dan password yang sesuai dengan input. Menggunakan ? sebagai placeholder untuk parameter binding, yang akan diisi dengan nilai sebenarnya nanti.
        String sql = "select * from users where username = ? AND password = ?";
        try (
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setString(1, p_mrd.getUsername()); //Placeholder di dalam query SQL diisi dengan nilai username dan password dari objek p_mrd.
            ps.setString(2, p_mrd.getPassword());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User(
                    rs.getInt("id"), 
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                );                
            }
        }
        
        return user;
    } 
    
    //Metode ini mencari pengguna berdasarkan id
    public User getUserById(int id) throws SQLException {
        User user = null;
        
        String sql = "select * from users where id = ?";
        try (
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new User(
                    rs.getInt("id"), 
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                );                
            }
        }
        
        return user;
    } 
        
    //Metode ini mengambil semua pengguna dengan peran siswa dari tabel users dan mengembalikannya dalam bentuk List<User>. 
    public List<User> getAllSiswa() throws SQLException {
        List<User> list_siswa = new ArrayList();
        
        String sql = "select * from users WHERE role = 'siswa'";
        try (
                Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
        ) {
            while(rs.next()) {
                User siswa = new User(
                        rs.getInt("id"), 
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
                
                list_siswa.add(siswa);
            }
        }
        
        return list_siswa;
    } 
    
    //metode ini mengambil semua pengguna dengan peran guru dari tabel users.
    public List<User> getAllGuru() throws SQLException {
        List<User> list_guru = new ArrayList();
        
        String sql = "select * from users WHERE role = 'guru'";
        try (
                Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
        ) {
            while(rs.next()) {
                User guru = new User(
                        rs.getInt("id"), 
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
                
                list_guru.add(guru);
            }
        }
        
        return list_guru;
    } 
    
    //Metode ini digunakan untuk menambahkan pengguna baru ke tabel users. Metode ini menerima objek User, lalu mengekstrak username, password, dan role untuk disimpan ke dalam database
    public void InsertUser(User p_mrd) throws SQLException {
        String sql = "insert into users (username, password, role) values (?, ?, ?)";
    
        try (
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
        ) {
            stmt.setString(1, p_mrd.getUsername());
            stmt.setString(2, p_mrd.getPassword());
            stmt.setString(3, p_mrd.getRole());
            
            stmt.executeUpdate();
        }
    }
    
    //Metode ini mengubah data pengguna yang ada berdasarkan id. Hanya username dan password yang diperbarui.
    public void updateUser(User p_mrd) throws SQLException {
        String sql = "UPDATE users SET username = ?, password = ? WHERE id = ?";

        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
         ) {
            stmt.setString(1, p_mrd.getUsername());
            stmt.setString(2, p_mrd.getPassword());
            stmt.setInt(3, p_mrd.getId());

            stmt.executeUpdate();
        }
    }
    
    //Metode ini menghapus pengguna berdasarkan id. Metode ini berguna untuk menghapus data pengguna dari database.
    public void deleteUser(int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id = ?";

        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);

            stmt.executeUpdate();
        }
    }
    
    //Metode ini memeriksa apakah username tertentu sudah ada di database.
    public boolean cekData(String username) throws SQLException {
    String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
    try (Connection conn = getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)
     ) {
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0; // Jika count > 0, berarti username sudah ada
        }
    }
    return false;
}
}


