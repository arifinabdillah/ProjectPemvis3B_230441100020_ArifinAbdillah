/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author DIKNAS
 */
public class koneksi {
    // Atribut ini menyimpan detail konfigurasi untuk menghubungkan aplikasi dengan database db_edukasi
    private static final String URL = "jdbc:mysql://localhost:3306/db_edukasi";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    //digunakan untuk membuat koneksi ke database dengan URL, nama pengguna, dan kata sandi yang sudah didefinisikan. Jika koneksi berhasil dibuat, metode ini akan mengembalikan objek Connection.
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}

