/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 *
 * @author DIKNAS
 */
public class T_Chat {
    private final String URL = "jdbc:mysql://localhost:3306/db_edukasi";
    private final String USER = "root";
    private final String PASS = "";

    Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public List<Chat> getAllMessages() throws SQLException {
        List<Chat> messages = new ArrayList<>();
        String sql = "SELECT * FROM chat ORDER BY timestamp ASC";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Chat chat = new Chat(
                        rs.getInt("id_user"),
                        rs.getString("message"),
                        rs.getTimestamp("timestamp")
                );
                chat.setId(rs.getInt("id"));
                messages.add(chat);
            }
        }
        return messages;
    }

    public void insertMessage(Chat chat) throws SQLException {
        String sql = "INSERT INTO chat (id_user, message, timestamp) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, chat.getUserId());
            stmt.setString(2, chat.getMessage());
            stmt.setTimestamp(3, new java.sql.Timestamp(chat.getTimestamp().getTime()));
            stmt.executeUpdate();
        }
    }
}
