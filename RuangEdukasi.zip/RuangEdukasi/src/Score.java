/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DIKNAS
 */
public class Score {
    private int id;
    private int userId;
    private int score;
    
    public Score(int p_id, int p_userId, int p_score) {
        this.id = p_id;
        this.userId = p_userId;
        this.score = p_score;
    }

    // Getters and setters
    public void setId(int p_id) {
        this.id = p_id;
    }
    public int getId() {
        return id;
    }
   
   public void setuserId(int p_userId) {
        this.userId = p_userId;
    }
    public int getuserId() {
        return userId;
    }
    
    public void setscore(int p_score) {
        this.score = p_score;
    }
    public int getscore() {
        return score;
    }
   
}
