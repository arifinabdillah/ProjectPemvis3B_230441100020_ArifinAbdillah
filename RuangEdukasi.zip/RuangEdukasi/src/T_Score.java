/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author DIKNAS
 */
public class T_Score {
    private final String URL = "jdbc:mysql://localhost:3306/db_edukasi";
    private final String USER = "root";
    private final String PASS = ""; //default string kosong

    Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
    
    public List<Score> getAllScores() throws SQLException {
        List<Score> list_scores = new ArrayList<>();
        
        String sql = "SELECT * FROM score";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Score score = new Score(
                        rs.getInt("id"),
                        rs.getInt("id_user"),
                        rs.getInt("score")
                );
                list_scores.add(score);
            }
        }
        return list_scores;
    }

    public void insertScore(Score score) throws SQLException {
        String sql = "INSERT INTO score (id, id_user, score) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, score.getId());
            stmt.setInt(2, score.getuserId());
            stmt.setInt(3, score.getscore());
            stmt.executeUpdate();
        }
    }
}
