/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DIKNAS
 */
public class User {
    private int id;
    private String username, password, role;
    
    //Konstruktor kelas User menerima parameter untuk menginisialisasi setiap atribut (id, username, password, role) ketika objek User baru dibuat.
    public User (int p_id, String p_Username, String p_Password, String p_Role) {
        this.id = p_id;
        this.username = p_Username;
        this.password = p_Password;
        this.role = p_Role;
    }
    
    //Metode yang mengubah nilai dari atribut dan mengembalikan nilai dari atribut
    public void setId(int p_id) {
        this.id = p_id;
    }
    public int getId() {
        return id;
    }
    
    public void setUsername(String p_Username) {
        this.username = p_Username;
    }
    public String getUsername() {
        return username;
    }
    
    public void setPassword(String p_Password) {
        this.password = p_Password;
    }
    public String getPassword() {
        return password;
    }

    public void setRole(String role) {
        this.role = role;
    }
    public String getRole() {
        return role;
    }
}
